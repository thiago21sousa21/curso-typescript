function sum(num1: number, num2: number) {
  return num1 + num2;
}

const result = sum(1, 2);
console.log(result); // 3